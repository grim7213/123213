const TelegramBotApi = require('node-telegram-bot-api')

const token = '7186873019:AAE_Ndz6T0RO7O912hyikrZu7aO0l-nUPh8';

const bot = new TelegramBotApi(token,{polling:true});

const axios = require('axios');



let height = 0;
let boop = 0;
let weight = 0;
let years = 0;
let counter = 0;
let current_models;
let girl_num =0;
let globalModel = null; // Глобальная переменная для хранения модели



var girl_num_arr

let currentModelIndex = 0;

const sendRequestToExpressServer = async (param_filter) => {
    try {
      // Преобразование диапазона перед отправкой запроса
      const parseRange = (range) => {
        const [minStr, maxStr] = range.split('-');
        let min = parseInt(minStr);
        let max = parseInt(maxStr);
        
        // Проверяем наличие знака "+"
        if (range.includes('+')) {
          min = max;
          max = null;
        }
  
        return { min, max };
      };
  
      // Преобразуем диапазоны для каждого параметра фильтра
      const params = {};
      if (param_filter.height) {
          const { min, max } = parseRange(param_filter.height);
          params.height = max ? `${min}-${max}cm` : `${min}+cm`;
      }
      if (param_filter.weight) {
          const { min, max } = parseRange(param_filter.weight);
          params.weight = max ? `${min}-${max}kg` : `${min}+kg`;
      }
      if (param_filter.years) {
          const { min, max } = parseRange(param_filter.years);
          params.years = max ? `${min}-${max} years` : `${min}+ years`;
      }
      if (param_filter.boops) {
          const { min, max } = parseRange(param_filter.boops);
        //   params.boops = max ? `${min}-${max} size${size > 1 ? 's'.repeat(size - 1) : ''}` : `${min}+ size${size > 1 ? 's'.repeat(size - 1) : ''}`;
          params.years = max ? `${min}-${max} sizes` : `${min}+ sizes`;
      }
  
      // Отправляем запрос на сервер Express
      const response = await axios.get('http://localhost:3000/get_models', { params });
      current_models = response.data

      girl_num_arr = current_models.map(model => {
        return model.description
      });
    //   counter = current_models.length
      counter = current_models.length
      // Далее вы можете обработать ответ, например, отправить его пользователю в телеграм
    } catch (error) {
      console.error('Ошибка отправки запроса на сервер Express:', error);
    }
  };
  
const getAllModelsFunction = async () => {
    try {
  
      // Отправляем запрос на сервер Express
      const response = await axios.get('http://localhost:3000/get_all_models');
      current_models = response.data

      girl_num_arr = current_models.map(model => {
        return model.description
      });


    //   counter = current_models.length
      counter = current_models.length
      // Далее вы можете обработать ответ, например, отправить его пользователю в телеграм
    } catch (error) {
      console.error('Ошибка отправки запроса на сервер Express:', error);
    }
  };

async function getModelById(modelId) {
    try {
        const response = await axios.get(`http://localhost:3000/get_model_by_id?model_id=${modelId}`);
        globalModel = response.data; // Сохраняем полученную модель в глобальной переменной
        // Дальнейшая обработка полученной модели
    } catch (error) {
        console.error('Ошибка при получении модели:', error);
        // Обработка ошибки при получении модели
    }
}


const start = ()=>{
    bot.on('text', async msg => {


        try {
    
            if(msg.text.startsWith('/start')) {
                girl_num =0
                console.log('err')
            await bot.sendPhoto(msg.chat.id, 'https://i.ibb.co/ZNFp3J8/wlcome.png', {

                caption: '<b>⭐️ Welcome to Enamora, the pinnacle of personalized companionship and luxury experiences. ! \n\nAt Enamora, we believe in crafting unforgettable moments that transcend the ordinary, offering an exclusive selection of companions who are not only breathtakingly beautiful but also intellectually engaging and genuinely passionate about making every encounter uniquely satisfying.</b>',
                parse_mode: 'HTML',
                reply_markup: {

                    keyboard: [
        
                        ['🧑‍💻 Manager', '🔥 Models'],
                        ['🌏 Website', 'ℹ️ Information'],
                        ['❌ Close']
        
                    ],
                    resize_keyboard: true
        
                }

            });


                if(msg.text.length > 6) {
    
    
                    await bot.sendMessage(msg.chat.id, `<b>You are in the main menu</b>`);
    
                }
    
            }

            else if(msg.text == '🌏 Website') {

                await bot.sendMessage(msg.chat.id, `https://habr.com/`,{
                    reply_markup: {

                        keyboard: [
            
                            ['🏠 Main menu']
            
                        ],
                        resize_keyboard: true
            
                    }
                });
            
            }

            else if(msg.text == 'ℹ️ Information') {
    
                await bot.sendMessage(msg.chat.id, `<b>Elite escort redefined. Discover the epitome of luxury and discretion with our handpicked selection of models. Exceptional service, unforgettable experiences!</b>`,{
                    parse_mode:"HTML",
                    reply_markup: {

                        keyboard: [
            

                            ['🏠 Main menu']
            
                        ],
                        resize_keyboard: true
            
                    }
                });
    
            }

            else if(msg.text == '/menu') {
    
                await bot.sendMessage(msg.chat.id,'Welcome back, what do you want ?',{

                    reply_markup: {

                        keyboard: [
            
                            ['🧑‍💻 Manager', '🔥 Models'],
                            ['🌏 Website', 'ℹ️ Information'],
                            ['❌ Close']
            
                        ],
                        resize_keyboard: true
            
                    }
            
                });
    
            }
            else if(msg.text == '❌ Close') {

                await bot.sendMessage(msg.chat.id, 'Menu closed, if you want to open it again, tap on the left command menu, and choose command: "Open menu"', {
            
                    reply_markup: {
            
                        remove_keyboard: true
            
                    }
            
                })
            
            }

            else if(msg.text == '🔥 Models') {



                await bot.sendPhoto(msg.chat.id, 'https://i.ibb.co/zRTzS5C/individual.png', {

                caption: '<b>⭐️ In our bot you can see all the models.</b>\n\nAlso, with filters, you can choose the best model, then contact the manager, he will arrange a meeting for you !',
                parse_mode: 'HTML',
                reply_markup: {

                    keyboard: [
        
                        ['🎛️ Filters', '👀 Show all'],
                        ['🔎 Find'],
                        ['🏠 Main menu']
        
                    ],
                    resize_keyboard: true
        
                }

            });
            }

            else if(msg.text == '🎛️ Filters'){
                await bot.sendPhoto(msg.chat.id, 'https://i.ibb.co/dB1J3wP/filtered.png', {

                caption: '<b>⭐️ Let`s filter models! !</b>',
                parse_mode: 'HTML',

            });
                await bot.sendMessage(msg.chat.id, 'Model height 📏',{
                    reply_markup: {

                        keyboard: [
            
                            ['150-165cm', '166-175cm'],
                            ['🏠 Main menu']
            
                        ],
                        resize_keyboard: true
            
                    }
                } )
            }

            else if(msg.text == '👀 Show all'){
                await getAllModelsFunction();


                const photoGroup = [];

                const model = current_models[girl_num];
                let descriptionAdded = false;

                if (model && model.additional_image) {
                    for (let i = 0; i < model.additional_image.length; i++) {
                        const imageUrl = model.additional_image[i];
                        let caption = '';
                        if (!descriptionAdded && i === 0) {
                            caption = `<b>Имя:</b> <i>${model.name}</i> \n<b>Height:</b> <i>${model.height} cm</i> \n<b>Weight:</b> <i>${model.weight} kg</i>\n<b>Model number:</b> <i>${model.model_id}</i>\n\n<b>1 Hour:</b> <i>${model.price[0]} AED\n</i><b>2 Hours:</b> <i>${model.price[1]} AED\n</i><b>Night:</b> <i>${model.price[2]} AED\n</i>\n\n<b>Description:</b> <i>${model.description}</i>\n\n<b>Services:</b> <i>${model.compliments[0]}</i>\n\n<b>Extra Services:</b> <i>${model.add_complimants}</i>`;
                            descriptionAdded = true;
                        }
                        photoGroup.push({
                            type: 'photo',
                            parse_mode:'HTML',
                            media: imageUrl,
                            caption: caption
                        });
                    }
                }
                
                await bot.sendMessage(msg.chat.id, '✨✨✨', {
                    parse_mode: 'HTML',
                    disable_notification: true,
                    reply_markup: {
                        keyboard: [
                            ['✅ Checkout'],
                            ['🔎 Find','Next 👉'],

                            ['🏠 Main menu']
                        ],
                        resize_keyboard: true
                    }
                });

                await bot.sendMediaGroup(msg.chat.id, photoGroup, {
                    // caption: `${current_models[girl_num].description}`,
                    parse_mode: 'HTML',
                    reply_markup: {
                        keyboard: [
                            ['Оформить'],
                            ['Назад', 'Номер модели','Дальше'],

                            ['❌ Главное меню']
                        ],
                        resize_keyboard: true
                    }
                });
            }

            else if(msg.text.includes('cm')) {

                height = msg.text
                await bot.sendMessage(msg.chat.id,'Great, now the breast size 😊',{
                    reply_markup: {

                        keyboard: [
            
                            ['1-2 sizes', '3-4 sizes'],
                            ['🏠 Main menu']
            
                        ],
                        resize_keyboard: true
            
                    }
                } )
            }
  
            else if(msg.text.includes('size')) {

                boop = msg.text
                await bot.sendMessage(msg.chat.id,'Model weight ⚖️',{
                    reply_markup: {

                        keyboard: [
            
                            ['40-55kg', '56-65kg'],
                            ['🏠 Main menu']
            
                        ],
                        resize_keyboard: true
            
                    }
                } )
            }


            else if(msg.text.includes('kg')) {

                weight = msg.text
                await bot.sendMessage(msg.chat.id,'And the last thing is the age of the model 🔞',{
                    reply_markup: {

                        keyboard: [
            
                            ['19-25 years', '26-35 years'],
                            ['🏠 Main menu']
            
                        ],
                        resize_keyboard: true
            
                    }
                } )
            }

            else if(msg.text.includes('years')) {

                years = msg.text
                let filter = {
                    'height':height,
                    'weight': weight,
                    'years': years,
                    'boop':boop,
  
                }

                await sendRequestToExpressServer(filter);


                const photoGroup = [];

                const model = current_models[girl_num];
                let descriptionAdded = false;

                if (model && model.additional_image) {
                    for (let i = 0; i < model.additional_image.length; i++) {
                        const imageUrl = model.additional_image[i];
                        let caption = '';
                        if (!descriptionAdded && i === 0) {
                            caption = `<b>Имя:</b> <i>${model.name}</i> \n<b>Height:</b> <i>${model.height} cm</i> \n<b>Weight:</b> <i>${model.weight} kg</i>\n<b>Model number:</b> <i>${model.model_id}</i>\n\n<b>1 Hour:</b> <i>${model.price[0]} AED\n</i><b>2 Hours:</b> <i>${model.price[1]} AED\n</i><b>Night:</b> <i>${model.price[2]} AED\n</i>\n\n<b>Description:</b> <i>${model.description}</i>\n\n<b>Services:</b> <i>${model.compliments[0]}</i>\n\n<b>Extra Services:</b> <i>${model.add_complimants}</i>`;
                            descriptionAdded = true;
                        }
                        photoGroup.push({
                            type: 'photo',
                            parse_mode:'HTML',
                            media: imageUrl,
                            caption: caption
                        });
                    }
                }
                
                await bot.sendMessage(msg.chat.id, '✨✨✨', {
                    parse_mode: 'HTML',
                    disable_notification: true,
                    reply_markup: {
                        keyboard: [
                            ['✅ Checkout'],
                            ['🔎 Find','Next 👉'],

                            ['🏠 Main menu']
                        ],
                        resize_keyboard: true
                    }
                });

                await bot.sendMediaGroup(msg.chat.id, photoGroup, {
                    // caption: `${current_models[girl_num].description}`,
                    parse_mode: 'HTML',
                    reply_markup: {
                        keyboard: [
                            ['Оформить'],
                            ['Назад', 'Номер модели','Дальше'],

                            ['❌ Главное меню']
                        ],
                        resize_keyboard: true
                    }
                });

                
            }

            else if(msg.text == "Next 👉") {
                girl_num = 1 + girl_num

                const photoGroup = [];

                const model = current_models[girl_num];
                let descriptionAdded = false;

                if (model && model.additional_image) {
                    for (let i = 0; i < model.additional_image.length; i++) {
                        const imageUrl = model.additional_image[i];
                        let caption = '';
                        if (!descriptionAdded && i === 0) {
                            caption = `<b>Name:</b> <i>${model.name}</i> \n<b>Height:</b> <i>${model.height} cm</i> \n<b>Weight:</b> <i>${model.weight} kg</i>\n<b>Model number:</b> <i>${model.model_id}</i>\n\n<b>1 Hour:</b> <i>${model.price[0]} AED\n</i><b>2 Hours:</b> <i>${model.price[1]} AED\n</i><b>Night:</b> <i>${model.price[2]} AED\n</i>\n\n<b>Description:</b> <i>${model.description}</i>\n\n<b>Services:</b> <i>${model.compliments[0]}</i>\n\n<b>Extra Services:</b> <i>${model.add_complimants}</i>`;
                            descriptionAdded = true;
                        }
                        photoGroup.push({
                            type: 'photo',
                            parse_mode:'HTML',
                            media: imageUrl,
                            caption: caption
                        });
                    }
                }


                if (girl_num == counter-1) {
                    await bot.sendMessage(msg.chat.id, '✨✨✨', {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['✅ Checkout'],
                                ['👈 Back','🔎 Find'],
    
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });

                    await bot.sendMediaGroup(msg.chat.id, photoGroup, {
                        caption: `${current_models[girl_num].description}`,
                        parse_mode: 'HTML',
                    });
                } else {
                    await bot.sendMessage(msg.chat.id, '✨✨✨', {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['✅ Checkout'],
                                ['👈 Back','🔎 Find','Next 👉'],
    
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });
                    await bot.sendMediaGroup(msg.chat.id, photoGroup, {
                    caption: `${current_models[girl_num].description}`,
                    parse_mode: 'HTML',
                    reply_markup: {
                        keyboard: [
                            ['✅ Checkout'],
                            ['👈 Back', '🔎 Find','Next 👉'],

                            ['❌ Главное меню']
                        ],
                        resize_keyboard: true
                    }
                }); 
                }
                
            }

            else if(msg.text == "👈 Back") {
                girl_num = girl_num-1

                const photoGroup = [];

                const model = current_models[girl_num];
                let descriptionAdded = false;

                if (model && model.additional_image) {
                    for (let i = 0; i < model.additional_image.length; i++) {
                        const imageUrl = model.additional_image[i];
                        let caption = '';
                        if (!descriptionAdded && i === 0) {
                            caption = `<b>Имя:</b> <i>${model.name}</i> \n<b>Height:</b> <i>${model.height} cm</i> \n<b>Weight:</b> <i>${model.weight} kg</i>\n<b>Model number:</b> <i>${model.model_id}</i>\n\n<b>1 Hour:</b> <i>${model.price[0]} AED\n</i><b>2 Hours:</b> <i>${model.price[1]} AED\n</i><b>Night:</b> <i>${model.price[2]} AED\n</i>\n\n<b>Description:</b> <i>${model.description}</i>\n\n<b>Services:</b> <i>${model.compliments[0]}</i>\n\n<b>Extra Services:</b> <i>${model.add_complimants}</i>`;
                            descriptionAdded = true;
                        }
                        photoGroup.push({
                            type: 'photo',
                            parse_mode:'HTML',
                            media: imageUrl,
                            caption: caption
                        });
                    }
                }
                
       

                if(girl_num == 0){
                    await bot.sendMessage(msg.chat.id, '✨✨✨', {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['✅ Checkout'],
                                ['🔎 Find','Next 👉'],
    
                                ['🏠 Main Menu']
                            ],
                            resize_keyboard: true
                        }
                    });

                    await bot.sendMediaGroup(msg.chat.id, photoGroup, {
                        caption: `${current_models[girl_num].description}`,
                        parse_mode: 'HTML',
                        reply_markup: {
                            keyboard: [
                                ['✅ Checkout'],
                                ['👈 Back', '🔎 Find','Next 👉'],
    
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });
                }else{
                    await bot.sendMessage(msg.chat.id, '✨✨✨', {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['✅ Checkout'],
                                ['👈 Back', '🔎 Find','Next 👉'],
    
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });

                    await bot.sendMediaGroup(msg.chat.id, photoGroup, {
                        caption: `${current_models[girl_num].description}`,
                        parse_mode: 'HTML',
                        reply_markup: {
                            keyboard: [
                                ['✅ Checkout'],
                                ['👈 Back', '🔎 Find','Next 👉'],
    
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });
                }

            }

            else if(msg.text == ('🏠 Main menu')) {
                girl_num =0
                globalModel = null


            await bot.sendPhoto(msg.chat.id, 'https://i.ibb.co/BsZrtyd/mainmenu.png', {

                caption: '<b>🏠 You are in the main menu</b>',
                parse_mode: 'HTML',
                reply_markup: {

                    keyboard: [
        
                        ['🧑‍💻 Manager', '🔥 Models'],
                        ['🌏 Website', 'ℹ️ Information'],
                        ['❌ Close']
        
                    ],
                    resize_keyboard: true
        
                }

            });
    
            }

            else if(msg.text == ('🔎 Find')) {
      
                await bot.sendMessage(msg.chat.id, '🥰 Enter the number of the model you like !', {
                    parse_mode: 'HTML',
                    disable_notification: true,
                    reply_markup: {
                        keyboard: [

                            ['🏠 Main menu']
                        ],
                        resize_keyboard: true
                    }
                });
    
            }

            else if(msg.text == ('🔎 Enother model')) {


                
                await bot.sendMessage(msg.chat.id, '🥰 Enter the number of the model you like !', {
                    parse_mode: 'HTML',
                    disable_notification: true,
                    reply_markup: {
                        keyboard: [
                            ['🏠 Main menu']
                        ],
                        resize_keyboard: true
                    }
                });
    
            }

            else if(msg.text == ('🧑‍💻 Manager')) {
                await bot.sendPhoto(msg.chat.id, 'https://i.ibb.co/zRTzS5C/individual.png', {

                    caption: '<b>🧑‍💻 A free manager is already waiting for you</b>',
                    parse_mode: 'HTML',

                });
                await bot.sendMessage(msg.chat.id, `You can contact to <a href="t.me/vikktoria55">Victoria</a>`, {
                    parse_mode: 'HTML',
                    disable_notification: true,
                    reply_markup: {
                        keyboard: [
                            ['🏠 Main menu']
                        ],
                        resize_keyboard: true
                    }
                });

                
    
            }

            else if(msg.text == ('✅ Checkout')) {



                if (globalModel == null) {

                    await bot.sendMessage(msg.chat.id, '✨✨✨', {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });

                    await bot.sendPhoto(msg.chat.id, `${current_models[girl_num].additional_image[0]}`, {

                    caption: `<b><code>${current_models[girl_num].name}</code></b>`,
                    parse_mode: 'HTML',

                    }); 

                    await bot.sendMessage(msg.chat.id, `You can contact to <a href="t.me/vikktoria55">Victoria</a>`, {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });
                    
                } else {

                    await bot.sendMessage(msg.chat.id, '✨✨✨', {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });

                    await bot.sendPhoto(msg.chat.id, `${globalModel.additional_image[0]}`, {

                    caption: `<b><code>${globalModel.name}, Model number: ${globalModel.model_id}</code></b>`,
                    parse_mode: 'HTML',

                    });  

                    await bot.sendMessage(msg.chat.id, `You can contact to <a href="t.me/vikktoria55">Victoria</a>`, {
                        parse_mode: 'HTML',
                        disable_notification: true,
                        reply_markup: {
                            keyboard: [
                                ['🏠 Main menu']
                            ],
                            resize_keyboard: true
                        }
                    });
                }

                globalModel = null
    
            }

            else if(msg.text > 0) {
                await getModelById(parseInt(msg.text) )



                const photoGroup = [];

                let uniq_model = globalModel;
                let descriptionAdded = false;


                if (uniq_model && uniq_model.additional_image) {
                    for (let i = 0; i < uniq_model.additional_image.length; i++) {
                        const imageUrl = uniq_model.additional_image[i];
                        let caption = '';
                        if (!descriptionAdded && i === 0) {
                            caption = `<b>Name:</b> <i>${uniq_model.name}</i> \n<b>Height:</b> <i>${uniq_model.height} cm</i> \n<b>Weight:</b> <i>${uniq_model.weight} kg</i>\n<b>Model number:</b> <i>${uniq_model.model_id}</i>\n\n<b>1 Hour:</b> <i>${uniq_model.price[0]} AED\n</i><b>2 Hours:</b> <i>${uniq_model.price[1]} AED\n</i><b>Night:</b> <i>${uniq_model.price[2]} AED\n</i>\n\n<b>Description:</b> <i>${uniq_model.description}</i>\n\n<b>Services:</b> <i>${uniq_model.compliments[0]}</i>\n\n<b>Extra Services:</b> <i>${uniq_model.add_complimants}</i>`;
                            descriptionAdded = true;
                        }
                        photoGroup.push({
                            type: 'photo',
                            parse_mode:'HTML',
                            media: imageUrl,
                            caption: caption
                        });
                    }
                }
                
                await bot.sendMessage(msg.chat.id, '✨✨✨', {
                    parse_mode: 'HTML',
                    disable_notification: true,
                    reply_markup: {
                        keyboard: [
                            ['✅ Checkout'],
                            ['🔎 Enother model'],

                            ['🏠 Main menu']
                        ],
                        resize_keyboard: true
                    }
                });

                await bot.sendMediaGroup(msg.chat.id, photoGroup, {
                    // caption: `${current_models[girl_num].description}`,
                    parse_mode: 'HTML',
                    reply_markup: {
                        keyboard: [
                            ['Оформить'],
                            ['Назад', 'Номер модели','Дальше'],

                            ['❌ Главное меню']
                        ],
                        resize_keyboard: true
                    }
                });

                // await bot.sendMessage(msg.chat.id, msg.text, {
                //     parse_mode: 'HTML',
                //     disable_notification: true,
                //     reply_markup: {
                //         keyboard: [
                //             ['Оформить'],
                //             ['Номер модели','Дальше'],

                //             ['❌ Главное меню']
                //         ],
                //         resize_keyboard: true
                //     }
                // });

    
            }

            else {
    
                await bot.sendMessage(msg.chat.id, 'nothing');
                console.log('nothing')
    
            }

    
        }
        catch(error) {
    
            console.log(error);
    
        }
    
    })

}


const commands = [

    {

        command: "start",
        description: "Start bot"

    },
    {

        command: "website",
        description: "Visit our website"

    },
    {

        command: "menu",
        description: "Open menu"

    },

]

bot.setMyCommands(commands);

start();