const express = require('express');
const mongoose = require('mongoose');
const app = express();

// Подключение к MongoDB
mongoose.connect('mongodb+srv://grim7213:H2MCR7OsxulWIkH6@cluster0.ccbdmkq.mongodb.net/');
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'Ошибка подключения к MongoDB:'));
db.once('open', function() {
  console.log('Успешное подключение к MongoDB');
});

// Определение схемы и модели
const { Schema } = mongoose;

app.use(express.json());

const Scheme_own = new Schema({
  main_image_url: String,
  additional_image: [String],
  name: String,
  height: Number,
  weight: Number,
  years: Number,
  boop: Number,
  model_id: Number, // model_id остается числом
  price: [Number],
  description: String,
  compliments: [String],
  add_complimants: [String],
});

const model = mongoose.model('model', Scheme_own);

// Маршрут для получения данных из MongoDB
app.get('/get_models', async (req, res) => {
    try {
      const { height, weight, years, boop } = req.query;
  
      // Парсим строку-диапазон и получаем минимальное и максимальное значение
      const parseRange = (range) => {
        const [minStr, maxStr] = range.split('-');
        const min = minStr === '' ? null : parseInt(minStr);
        const max = maxStr === '' ? null : parseInt(maxStr);
        return { min, max };
      };
  
      const heightRange = height ? parseRange(height) : null;
      const weightRange = weight ? parseRange(weight) : null;
      const yearsRange = years ? parseRange(years) : null;
      const boopsRange = boop ? parseRange(boop) : null;
  
      // Подготавливаем объект для фильтрации
      const filter = {};
      if (heightRange) {
        if (heightRange.min !== null) filter.height = { $gte: heightRange.min };
        if (heightRange.max !== null) filter.height = { ...filter.height, $lte: heightRange.max };
      }
      if (weightRange) {
        if (weightRange.min !== null) filter.weight = { $gte: weightRange.min };
        if (weightRange.max !== null) filter.weight = { ...filter.weight, $lte: weightRange.max };
      }
      if (yearsRange) {
        if (yearsRange.min !== null) filter.years = { $gte: yearsRange.min };
        if (yearsRange.max !== null) filter.years = { ...filter.years, $lte: yearsRange.max };
      }
      if (boopsRange) {
        if (boopsRange.min !== null) filter.boop = { $gte: boopsRange.min };
        if (boopsRange.max !== null) filter.boop = { ...filter.boop, $lte: boopsRange.max };
      }
  
      // Выполняем запрос с применением фильтра
      const result = await model.find(filter);
      res.json(result);
    } catch (error) {
      console.error('Ошибка запроса:', error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/get_all_models', async (req, res) => {
    try {
      const { height, weight, years, boop } = req.query;
  
      // Парсим строку-диапазон и получаем минимальное и максимальное значение
      const parseRange = (range) => {
        const [minStr, maxStr] = range.split('-');
        const min = minStr === '' ? null : parseInt(minStr);
        const max = maxStr === '' ? null : parseInt(maxStr);
        return { min, max };
      };
  
      const heightRange = height ? parseRange(height) : null;
      const weightRange = weight ? parseRange(weight) : null;
      const yearsRange = years ? parseRange(years) : null;
      const boopsRange = boop ? parseRange(boop) : null;
  
      // Подготавливаем объект для фильтрации
      const filter = {};
      if (heightRange) {
        if (heightRange.min !== null) filter.height = { $gte: heightRange.min };
        if (heightRange.max !== null) filter.height = { ...filter.height, $lte: heightRange.max };
      }
      if (weightRange) {
        if (weightRange.min !== null) filter.weight = { $gte: weightRange.min };
        if (weightRange.max !== null) filter.weight = { ...filter.weight, $lte: weightRange.max };
      }
      if (yearsRange) {
        if (yearsRange.min !== null) filter.years = { $gte: yearsRange.min };
        if (yearsRange.max !== null) filter.years = { ...filter.years, $lte: yearsRange.max };
      }
      if (boopsRange) {
        if (boopsRange.min !== null) filter.boop = { $gte: boopsRange.min };
        if (boopsRange.max !== null) filter.boop = { ...filter.boop, $lte: boopsRange.max };
      }
  
      // Выполняем запрос с применением фильтра
      const result = await model.find();
      res.json(result);
    } catch (error) {
      console.error('Ошибка запроса:', error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/get_model_by_id', async (req, res) => {
    const modelId = parseInt(req.query.model_id); // Получаем значение параметра model_id из запроса
    try {
        // Ищем модель по model_id в базе данных
        const id_result = await model.findOne({ model_id: modelId });
        if (id_result) {
            res.json(id_result); // Отправляем найденную модель в формате JSON
        } else {
            res.status(404).json({ error: 'Model not found' }); // Если модель не найдена, отправляем ошибку 404
        }
    } catch (error) {
        console.error('Error fetching model:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});
  

app.post('/new_model', async (req, res) => {
    try {
      const newObj = new model({
        main_image_url: req.body.main_image_url,
        additional_image: req.body.additional_image,
        name: req.body.name,
        height: req.body.height,
        weight: req.body.weight,
        years: req.body.years,
        boop:req.body.boop,
        model_id: req.body.model_id,
        price:req.body.price,
        description:req.body.description,
        compliments:req.body.compliments,
        add_complimants:req.body.add_complimants,
        
      });
      await newObj.save();
      res.json({ message: 'Данные успешно добавлены в базу данных' });
    } catch (error) {
      console.error('Ошибка при добавлении данных:', error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
  });

  // Маршрут для удаления модели по идентификатору
  app.delete('/models/:model_id', async (req, res) => {
    const modelId = req.params.model_id;

    try {
        // Находим модель по model_id
        const foundModel = await model.findOne({ model_id: modelId });

        if (!foundModel) {
            return res.status(404).json({ error: 'Модель не найдена' });
        }

        // Удаляем найденную модель
        const deletedModel = await foundModel.deleteOne();

        return res.status(200).json({ message: 'Модель успешно удалена' });
    } catch (error) {
        console.error('Ошибка при удалении модели:', error);
        return res.status(500).json({ error: 'Ошибка сервера' });
    }
});





// Запуск сервера
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});
